
clc;    
close all;  
clear;  
workspace; 

map = jet(5);
cm = colormap(map);

[x1, y1] = getCircle([0,0], 1);
plot(x1, y1, 'Linewidth', 12.3, 'Color', cm(1,:))

hold on
[x2, y2] = getCircle([0,0], 2);
plot(x2, y2, 'Linewidth', 10.1, 'Color', cm(2,:))

hold on
[x3, y3] = getCircle([0,0], 3);
plot(x3, y3, 'Linewidth', 7.9, 'Color', cm(3,:))

hold on
[x4, y4] = getCircle([0,0], 4);
plot(x4, y4, 'Linewidth',5.7, 'Color', cm(4,:))


hold on
[x5, y5] = getCircle([0,0], 5);
plot(x5, y5, 'Linewidth',3.5, 'Color', cm(5,:))

axis equal


