


function [x,y]=getCircleg(center,r)
t=0:pi/360:2*pi;
x=[r*cos(t)+center(1)];
y=[r*sin(t)+center(2)];
end
