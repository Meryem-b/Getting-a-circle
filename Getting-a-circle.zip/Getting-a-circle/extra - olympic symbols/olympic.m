

clc;
clear;

[bx5,by5]=getCirclea([0,0],0.42)
plot(bx5,by5,'k','Linewidth',9)
hold on

[yx3,yy3]=getCircleg([0.5,-0.5],0.42)
plot(yx3,yy3,'g','Linewidth',9)
hold on

[kx1,ky1]=getCirclea([1,0],0.42)
plot(kx1,ky1,'r','Linewidth',9)
hold on

[yx4,yy4]=getCircled([0.5,-0.5],0.42)
plot(yx4,yy4,'g','Linewidth',9)
hold on

[bx3,by3]=getCirclei([0,0],0.42)
plot(bx3,by3,'k','Linewidth',9)
hold on

[yx2,yy2]=getCirclec([0.5,-0.5],0.42)
plot(yx2,yy2,'g','Linewidth',9)
hold on

[yx1,yy1]=getCircleb([0.5,-0.5],0.42)
plot(yx1,yy1,'g','Linewidth',9)
hold on

[bx4,by4]=getCircleh([0,0],0.42)
plot(bx4,by4,'k','Linewidth',9)
hold on

[sx3,sy3]=getCircleg([-0.5,-0.5],0.42)
plot(sx3,sy3,'y','Linewidth',9)
hold on

[bx2,by2]=getCirclef([0,0],0.42)
plot(bx2,by2,'k','Linewidth',9)
hold on

[bx1,by1]=getCirclee([0,0],0.42)
plot(bx1,by1,'k','Linewidth',9)
hold on

[sx4,sy4]=getCircled([-0.5,-0.5],0.42)
plot(sx4,sy4,'y','Linewidth',9)
hold on

[sx1,sy1]=getCircleb([-0.5,-0.5],0.42)
plot(sx1,sy1,'y','Linewidth',9)
hold on

[mx1,my1]=getCirclea([-1,0],0.42)
plot(mx1,my1,'b','Linewidth',9)
hold on

[sx2,sy2]=getCirclec([-0.5,-0.5],0.42)
plot(sx2,sy2,'y','Linewidth',9)
axis equal


