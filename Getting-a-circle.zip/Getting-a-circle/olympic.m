

clc;
clear;

[x1,y1]=getCircle([-1,0],0.45)
plot(x1,y1,'b','Linewidth',4)
hold on

[x2,y2]=getCircle([0,0],0.45)
plot(x2,y2,'k','Linewidth',4)
hold on

[x3,y3]=getCircle([1,0],0.45)
plot(x3,y3,'r','Linewidth',4)
hold on

[x4,y4]=getCircle([-0.5,-0.5],0.45)
plot(x4,y4,'y','Linewidth',4)
hold on

[x5,y5]=getCircle([0.5,-0.5],0.45)
plot(x5,y5,'g','Linewidth',4)
axis equal


